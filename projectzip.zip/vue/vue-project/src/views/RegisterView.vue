
<template>
    <div>
      <Register />
    </div>
  </template>
  
  <script>
  import Register from '../components/Register.vue';
  
  export default {
    components: {
      Register
    }
  }
  </script>
  