<template>
    <div>
      <GetLoans />
    </div>
  </template>
  
  <script>
  import GetLoans from '../components/GetLoans.vue';
  
  export default {
    components: {
      GetLoans
    }
  }
  </script>
  