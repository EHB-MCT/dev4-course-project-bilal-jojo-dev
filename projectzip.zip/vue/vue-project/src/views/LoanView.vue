<template>
    <div>
      <Loan />
    </div>
  </template>
  
  <script>
  import Loan from '../components/Loan.vue';
  
  export default {
    components: {
      Loan
    }
  }
  </script>
  