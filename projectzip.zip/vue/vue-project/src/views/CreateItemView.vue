<template>
    <div>
      <h1>Create Item</h1>
      <CreateItem />
    </div>
  </template>
  
  <script>
  import CreateItem from '../components/CreateItem.vue';
  
  export default {
    components: {
      CreateItem,
    },
  }
  </script>