package ehb.multimedia.loans.exceptions

class GenericErrorResponse {



}