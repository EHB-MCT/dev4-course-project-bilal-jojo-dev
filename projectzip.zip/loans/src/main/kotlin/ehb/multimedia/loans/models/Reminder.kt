package ehb.multimedia.loans.models

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.util.Date
import java.util.StringJoiner
/*
@Entity
@Table(name = "reminders")
class Reminder {
    @Id
    @GeneratedValue
    val id: Int = 0
    val date: Date = Date()
    val message: String = ""
    val type: String = ""
}*/
