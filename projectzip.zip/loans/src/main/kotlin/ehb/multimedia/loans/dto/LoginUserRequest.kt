package ehb.multimedia.loans.dto

data class LoginUserRequest(val email: String, val password: String)