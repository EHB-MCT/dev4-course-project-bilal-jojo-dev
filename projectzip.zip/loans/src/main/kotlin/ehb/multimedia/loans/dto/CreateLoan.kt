package ehb.multimedia.loans.dto


data class CreateLoan(val itemId: Int, val userId: Int, val startDate: String, val endDate: String)

