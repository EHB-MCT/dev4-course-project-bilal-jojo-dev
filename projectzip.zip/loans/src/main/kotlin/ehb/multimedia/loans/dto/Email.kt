package ehb.multimedia.loans.dto

/*data class Email(
        val to: String,
        val subject: String,
        val text: String
)*/
